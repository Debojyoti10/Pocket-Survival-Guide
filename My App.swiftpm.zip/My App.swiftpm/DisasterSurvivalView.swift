import SwiftUI

struct DisasterSurvivalView: View {
    let disasters = [
        ("🌪️ Tornado", "Find shelter in a basement. If outside, lie in a ditch."),
        ("🌊 Tsunami", "Move inland or to higher ground immediately."),
        ("🔥 Wildfire", "Stay low, cover nose with a cloth, and move away from fire."),
        ("🌍 Earthquake", "Drop, cover, hold under sturdy furniture."),
        ("🌊 Flood", "Move to higher ground. Avoid walking in moving water.")
    ]
    
    var body: some View {
        List(disasters, id: \.0) { disaster in
            VStack(alignment: .leading) {
                Text(disaster.0).font(.headline).foregroundColor(.blue)
                Text(disaster.1).font(.subheadline)
            }
            .padding()
        }
        .navigationTitle("Disaster Survival")
    }
}
