import SwiftUI

// Wrapper struct for First Aid Tip
struct FirstAidTip: Identifiable {
    let id = UUID()
    let title: String
    let advice: String
}

struct FirstAidView: View {
    let tips = [
        FirstAidTip(title: "🩸 Bleeding", advice: """
        - Apply direct pressure with a clean cloth or sterile dressing.
        - Elevate the injured area if possible.
        - If bleeding is severe, apply a tourniquet above the wound.
        - Seek medical attention if bleeding does not stop within 10 minutes.
        """),
        
        FirstAidTip(title: "🔥 Burns", advice: """
        - Cool the burn with running water for at least 10 minutes.
        - Do not apply ice, butter, or ointments.
        - Cover with a sterile, non-stick dressing.
        - For severe burns (blisters, white/charred skin), seek emergency help.
        """),
        
        FirstAidTip(title: "💔 Fractures", advice: """
        - Keep the injured area still and do not try to realign the bone.
        - Support the injured limb using a splint or sling if available.
        - Apply ice packs (wrapped in cloth) to reduce swelling.
        - Seek medical attention immediately.
        """),
        
        FirstAidTip(title: "🤕 Head Injury", advice: """
        - Keep the person still and encourage them to stay awake.
        - Apply a cold compress to reduce swelling.
        - If unconscious, check for breathing and perform CPR if needed.
        - Seek medical help if the person experiences vomiting, confusion, or dizziness.
        """),
        
        FirstAidTip(title: "🐍 Snake Bite", advice: """
        - Keep the person calm and still to slow venom spread.
        - Immobilize the affected limb at or below heart level.
        - Do not suck out venom, apply ice, or use a tourniquet.
        - Seek emergency medical help immediately.
        """)
    ]
    
    @State private var selectedTip: FirstAidTip? = nil
    
    var body: some View {
        NavigationView {
            List(tips) { tip in
                Button(action: {
                    selectedTip = tip
                }) {
                    HStack {
                        Text(tip.title)
                            .font(.headline)
                            .foregroundColor(.red)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                    }
                    .padding()
                }
            }
            .navigationTitle("First Aid Guide")
            .sheet(item: $selectedTip) { tip in
                FirstAidDetailView(title: tip.title, advice: tip.advice)
            }
        }
    }
}

struct FirstAidDetailView: View {
    let title: String
    let advice: String
    
    @Environment(\.dismiss) var dismiss  // Allows closing the sheet
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    Text(advice)
                        .font(.body)
                        .padding()
                }
                .padding()
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        dismiss() // Close the detail view
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.red)
                            .font(.title2)
                    }
                }
            }
        }
    }
}
