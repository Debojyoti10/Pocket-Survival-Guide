import SwiftUI

// Define a struct to conform to Identifiable
struct SurvivalTip: Identifiable {
    let id = UUID()
    let title: String
    let description: String
}

struct WaterFoodGuideView: View {
    let survivalTips = [
        SurvivalTip(title: "💧 Finding Water", description: """
        - Collect rainwater using leaves, tarps, or containers.
        - Look for natural springs, streams, or rivers (flowing water is usually safer).
        - Dig a hole near a riverbank to let filtered groundwater seep in.
        - Use tree condensation by tying a plastic bag around leafy branches.
        - Watch for signs of water: green vegetation, insect activity, or animal tracks.
        """),
        
        SurvivalTip(title: "🔥 Purifying Water", description: """
        - **Boiling**: Bring water to a rolling boil for at least 1 minute (3 minutes at high altitudes).
        - **Filtration**: Use a cloth or sand/charcoal layers to remove debris.
        - **Solar Purification**: Fill a clear plastic bottle and leave it in the sun for 6 hours.
        - **Chemical Treatment**: Use iodine tablets or water purification drops.
        - Avoid drinking untreated water from stagnant pools or unknown sources.
        """),
        
        SurvivalTip(title: "🌿 Edible Plants", description: """
        - **Safe Options**: Dandelions, cattails, pine needles (for tea), and clover are commonly safe.
        - **Berries**: Avoid white or red berries unless you’re sure they are edible.
        - **Universal Edibility Test**: Rub a small part on your skin, then lips, then tongue—wait a few hours.
        - **Avoid**: Mushrooms, unknown beans, or plants with milky sap.
        - Nuts and seeds are generally safer and provide high energy.
        """),
        
        SurvivalTip(title: "🐟 Catching Food", description: """
        - **Fishing**: Use sharpened sticks, hooks, or makeshift nets from fabric.
        - **Traps**: Set simple deadfall or snare traps using bait.
        - **Foraging**: Look for protein-rich sources like insects (grasshoppers, crickets).
        - **Cooking**: Always cook meat or fish over fire to kill parasites.
        - **Avoid Risky Animals**: Some frogs, snakes, or sea creatures can be toxic.
        """)
    ]
    
    @State private var selectedTip: SurvivalTip? = nil  // Track selected tip
    
    var body: some View {
        NavigationView {
            List(survivalTips) { tip in
                Button(action: {
                    selectedTip = tip  // Show selected tip details
                }) {
                    HStack {
                        Text(tip.title)
                            .font(.headline)
                            .foregroundColor(.green)  // Updated font color
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                    }
                    .padding()
                }
            }
            .navigationTitle("Water & Food Survival")
            .sheet(item: $selectedTip) { tip in
                TipDetailView(tip: tip, closeAction: { selectedTip = nil })
            }
        }
    }
}

struct TipDetailView: View {
    let tip: SurvivalTip
    let closeAction: () -> Void  // Close action handler
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Spacer()
                    Button(action: closeAction) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title)
                            .foregroundColor(.red)
                    }
                    .padding()
                }
                
                Text(tip.title)
                    .font(.title2)
                    .foregroundColor(.blue)
                    .bold()
                    .padding(.horizontal)
                
                ScrollView {
                    Text(tip.description)
                        .font(.body)
                        .foregroundColor(.black)
                        .padding()
                }
            }
            .navigationTitle(tip.title)
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
