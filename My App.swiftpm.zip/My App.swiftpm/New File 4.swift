import SwiftUI

// Struct for Shelter Details
struct Shelter: Identifiable {
    let id = UUID()
    let name: String
    let description: String
}

struct ShelterGuideView: View {
    let shelters = [
        Shelter(name: "⛺ Lean-To Shelter", description: """
        - Find a long, sturdy branch and lean it against a tree or a support structure.
        - Place smaller branches diagonally against the main branch to create a wall.
        - Cover the wall with leaves, grass, or bark for insulation.
        - Use extra branches and leaves on the ground to create a dry bedding.
        - Ideal for short-term protection from wind and rain.
        """),
        
        Shelter(name: "🏕️ A-Frame Shelter", description: """
        - Create two strong supports (like two Y-shaped branches) and place a long branch across the top.
        - Lean sticks on both sides to form an A-shape.
        - Cover the frame with leaves, grass, or debris to insulate from rain and cold.
        - Ensure the opening is facing away from strong winds.
        - Suitable for moderate weather conditions.
        """),
        
        Shelter(name: "🌲 Snow Cave", description: """
        - Find a deep snowbank or pile snow to form a mound.
        - Dig a small entrance tunnel and widen the space inside.
        - Create a raised sleeping platform to prevent direct contact with the cold ground.
        - Poke a small air vent at the top to allow airflow.
        - Ensure the roof is thick enough to trap heat but not too heavy to collapse.
        - Ideal for winter survival in snowy regions.
        """),
        
        Shelter(name: "🪵 Debris Hut", description: """
        - Start by building a small frame using two branches in an upside-down V shape.
        - Lean branches against the frame to create a steep, triangular shape.
        - Cover the frame with a thick layer of leaves, grass, moss, or other insulating materials.
        - Add extra layers for better insulation against cold temperatures.
        - Great for retaining body heat in cold environments.
        """),
        
        Shelter(name: "🪨 Rock Overhang Shelter", description: """
        - Find a large rock or cave-like formation that offers natural overhead cover.
        - Build a windbreak using branches, stones, or stacked logs.
        - Add insulation using leaves and debris for warmth.
        - Make sure the area is stable and free from falling rocks.
        - Provides natural protection from rain and wind.
        """),
        
        Shelter(name: "🎋 Jungle Hammock Shelter", description: """
        - Find two strong trees about 10 feet apart.
        - Tie a hammock or construct one using vines and a durable cloth.
        - Create a tarp roof using large leaves, palm fronds, or waterproof material.
        - Keeps you off the ground, avoiding insects and damp terrain.
        - Ideal for tropical environments with heavy rainfall.
        """)
    ]
    
    @State private var selectedShelter: Shelter? = nil
    
    var body: some View {
        NavigationView {
            List(shelters) { shelter in
                Button(action: {
                    selectedShelter = shelter
                }) {
                    HStack {
                        Text(shelter.name)
                            .font(.headline)
                            .foregroundColor(.green)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                    }
                    .padding()
                }
            }
            .navigationTitle("Shelter Building")
            .sheet(item: $selectedShelter) { shelter in
                ShelterDetailView(shelter: shelter)
            }
        }
    }
}

struct ShelterDetailView: View {
    let shelter: Shelter
    
    @Environment(\.dismiss) var dismiss  // Allows dismissing the sheet
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    Text(shelter.description)
                        .font(.body)
                        .padding()
                }
                .padding()
            }
            .navigationTitle(shelter.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        dismiss() // Close the sheet
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.red)
                            .font(.title2)
                    }
                }
            }
        }
    }
}
