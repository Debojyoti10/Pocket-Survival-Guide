
import SwiftUI

@main
struct SurvivalGuideApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
