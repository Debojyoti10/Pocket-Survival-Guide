import SwiftUI
import CoreLocation

struct CompassView: View {
    @StateObject private var compassVM = CompassViewModel()
    
    var body: some View {
        VStack {
            Text("🧭 \(compassVM.heading, specifier: "%.0f")°")
                .font(.largeTitle)
                .padding()
        }
        .onAppear {
            compassVM.start()
        }
        .navigationTitle("Compass")
    }
}

class CompassViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()
    @Published var heading: Double = 0
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.startUpdatingHeading()
    }
    
    func start() {
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingHeading()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        heading = newHeading.trueHeading
    }
}
