import SwiftUI

struct EmergencyContactsView: View {
    @State private var contacts = [
        ("🏥 Hospital", "911"),
        ("🚔 Police", "100"),
        ("🔥 Fire Department", "101"),
        ("🚑 Ambulance", "102")
    ]
    
    var body: some View {
        List(contacts, id: \.0) { contact in
            HStack {
                VStack(alignment: .leading) {
                    Text(contact.0).font(.headline)
                    Text("📞 \(contact.1)").font(.subheadline)
                }
                Spacer()
                Button(action: {
                    callNumber(contact.1)
                }) {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.green)
                }
            }
            .padding()
        }
        .navigationTitle("Emergency Contacts")
    }
    
    func callNumber(_ number: String) {
        if let url = URL(string: "tel://\(number)"), UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
        }
    }
}
