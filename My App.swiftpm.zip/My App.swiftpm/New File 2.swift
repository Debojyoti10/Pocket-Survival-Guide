import SwiftUI

struct FireGuideView: View {
    let fireMethods = [
        ("🔥 Flint & Steel", "Strike steel against flint over dry tinder."),
        ("🔥 Bow Drill", "Use a bow drill with dry wood and groove."),
        ("🔥 Battery & Steel Wool", "Rub steel wool across a battery."),
        ("🔥 Magnifying Glass", "Focus sunlight onto dry tinder.")
    ]
    
    var body: some View {
        List(fireMethods, id: \.0) { method in
            VStack(alignment: .leading) {
                Text(method.0).font(.headline).foregroundColor(.orange)
                Text(method.1).font(.subheadline)
            }
            .padding()
        }
        .navigationTitle("Fire Making Guide")
    }
}


