import SwiftUI

struct DefenseGuideView: View {
    let defenseTips = [
        ("👊 Against a Grab", "Use your elbow to strike the attacker's ribs."),
        ("🦵 Against a Choke", "Push thumbs into attacker's eyes and kick the groin."),
        ("🔪 Against a Knife", "Keep distance, use objects like bags as a shield."),
        ("🐍 Snake Attack", "Back away slowly, avoid sudden movements."),
        ("🦁 Wild Animal", "Make yourself look bigger, stay calm, back away.")
    ]
    
    var body: some View {
        List(defenseTips, id: \.0) { tip in
            VStack(alignment: .leading) {
                Text(tip.0).font(.headline).foregroundColor(.red)
                Text(tip.1).font(.subheadline)
            }
            .padding()
        }
        .navigationTitle("Self-Defense Guide")
    }
}

