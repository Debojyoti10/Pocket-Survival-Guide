
import SwiftUI

// Define a struct to hold the feature name and the destination view
struct FeatureItem {
    let title: String
    let destination: AnyView
}

struct ContentView: View {
    let features: [FeatureItem] = [
        FeatureItem(title: "🔊 Emergency Alarm", destination: AnyView(SoundAlarmView())),
        FeatureItem(title: "🚑 First Aid Guide", destination: AnyView(FirstAidView())),
        FeatureItem(title: "💧 Water & Food Survival", destination: AnyView(WaterFoodGuideView())),
        FeatureItem(title: "🔥 Fire Making", destination: AnyView(FireGuideView())),
        FeatureItem(title: "⛺ Shelter Building", destination: AnyView(ShelterGuideView())),
        FeatureItem(title: "🥋 Self-Defense", destination: AnyView(DefenseGuideView())),
        FeatureItem(title: "🌪️ Disaster Survival", destination: AnyView(DisasterSurvivalView())),
        FeatureItem(title: "📞 Emergency Contacts", destination: AnyView(EmergencyContactsView())),
        FeatureItem(title: "🧭 Compass", destination: AnyView(CompassView()))
    ]
    
    var body: some View {
        NavigationView {
            List(features, id: \.title) { feature in
                NavigationLink(destination: feature.destination) {
                    Text(feature.title)
                        .font(.headline)
                        .padding()
                }
            }
            .navigationTitle("Pocket Survival Guide")
        }
    }
}
