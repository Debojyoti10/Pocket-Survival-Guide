import SwiftUI
import AVFoundation

struct SoundAlarmView: View {
    @State private var audioPlayer: AVAudioPlayer?
    @State private var isPlaying = false
    @State private var backgroundColor = Color.white
    @State private var timer: Timer?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Emergency Alarm")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.red)
                .accessibilityLabel("Emergency Alarm Screen")
            
            Button(action: {
                toggleAlarm()
            }) {
                Text(isPlaying ? "Stop Alarm" : "Activate Emergency Alarm")
                    .font(.title2)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(isPlaying ? Color.gray : Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .accessibilityLabel(isPlaying ? "Stop Alarm Button" : "Activate Emergency Alarm Button")
                    .accessibilityHint("Double tap to activate or stop the alarm")
            }
            .padding(.horizontal, 40)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(backgroundColor)
        .edgesIgnoringSafeArea(.all)
        .onDisappear {
            stopAlarm()
        }
        .navigationTitle("Emergency Alarm")
    }
    
    func toggleAlarm() {
        if isPlaying {
            stopAlarm()
        } else {
            playAlarm()
        }
    }
    
    func playAlarm() {
        guard let path = Bundle.main.path(forResource: "alarm", ofType: "mp3") else {
            print("Failed to load sound file")
            return
        }
        
        let url = URL(fileURLWithPath: path)
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.numberOfLoops = -1  // Loop indefinitely
            audioPlayer?.play()
            isPlaying = true
            triggerHapticFeedback()
            startVisualAlert()
        } catch {
            print("Failed to play sound")
        }
    }
    
    func stopAlarm() {
        audioPlayer?.stop()
        isPlaying = false
        backgroundColor = Color.white
        timer?.invalidate()
    }
    
    func triggerHapticFeedback() {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.error)
    }
    
    func startVisualAlert() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            withAnimation {
                backgroundColor = (backgroundColor == Color.white) ? Color.red.opacity(0.8) : Color.white
            }
        }
    }
}
